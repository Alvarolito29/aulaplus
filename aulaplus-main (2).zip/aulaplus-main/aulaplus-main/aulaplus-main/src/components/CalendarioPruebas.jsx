// src/components/CalendarioPruebas.jsx
import { useMemo, useState } from 'react';
import { Card, Button, Badge, ListGroup } from 'react-bootstrap';

const MESES = [
  'Enero','Febrero','Marzo','Abril','Mayo','Junio',
  'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'
];
const DIAS = ['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'];

function ymd(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export default function CalendarioPruebas({ events = [], initialDate = new Date() }) {
  // Siempre posicionamos el calendario en el día 1 del mes actual seleccionado
  const [current, setCurrent] = useState(
    new Date(initialDate.getFullYear(), initialDate.getMonth(), 1)
  );

  // Indexamos eventos por fecha 'YYYY-MM-DD'
  const eventsByDate = useMemo(() => {
    const map = new Map();
    for (const ev of events) {
      const key = ev.date;
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(ev);
    }
    return map;
  }, [events]);

  const todayStr = ymd(new Date());

  // Construcción de la grilla (6 filas x 7 columnas, siempre)
  const { cells, title, monthStr } = useMemo(() => {
    const y = current.getFullYear();
    const m = current.getMonth();
    const first = new Date(y, m, 1);
    // Lunes=0 → (Domingo=0 en JS) => (getDay()+6)%7
    const startOffset = (first.getDay() + 6) % 7;

    const totalCells = 42;
    const grid = [];
    for (let i = 0; i < totalCells; i++) {
      const dayNum = i - startOffset + 1;
      const dateObj = new Date(y, m, dayNum);
      grid.push({
        key: ymd(dateObj),
        dateObj,
        inMonth: dateObj.getMonth() === m,
      });
    }

    return {
      cells: grid,
      title: `${MESES[m]} ${y}`,
      monthStr: `${y}-${String(m + 1).padStart(2, '0')}`,
    };
  }, [current]);

  // Lista del mes (panel inferior)
  const monthEvents = useMemo(() => {
    return events
      .filter(e => e.date.startsWith(monthStr))
      .sort((a, b) => (a.date < b.date ? -1 : 1));
  }, [events, monthStr]);

  return (
    <Card className="shadow-sm rounded-3">
      <Card.Header className="d-flex justify-content-between align-items-center">
        <Button
          variant="outline-secondary"
          size="sm"
          onClick={() => setCurrent(new Date(current.getFullYear(), current.getMonth() - 1, 1))}
        >
          ‹ Mes
        </Button>
        <div className="fw-bold">{title}</div>
        <Button
          variant="outline-secondary"
          size="sm"
          onClick={() => setCurrent(new Date(current.getFullYear(), current.getMonth() + 1, 1))}
        >
          Mes ›
        </Button>
      </Card.Header>

      <Card.Body>
        {/* Cabecera de días */}
        <div
          className="mb-2"
          style={{ display: 'grid', gridTemplateColumns: 'repeat(7, minmax(0, 1fr))', gap: 6 }}
        >
          {DIAS.map(d => (
            <div key={d} className="text-center text-muted small fw-semibold">{d}</div>
          ))}
        </div>

        {/* Celdas (cuadradas) */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(7, minmax(0, 1fr))',
            gap: 6,
            overflow: 'hidden',
            maxWidth: '100%',
          }}
        >
          {cells.map(cell => {
            const dayEvents = eventsByDate.get(cell.key) || [];
            const isToday = cell.key === todayStr;

            return (
              <div
                key={cell.key}
                className="border rounded p-2"
                style={{
                  background: cell.inMonth ? '#fff' : '#f8f9fa',
                  borderColor: isToday ? '#0d6efd' : '#dee2e6',
                  boxShadow: isToday ? 'inset 0 0 0 1px #0d6efd' : undefined,
                  aspectRatio: '1 / 1',            // ← hace el cuadrito perfecto
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  overflow: 'hidden',
                }}
              >
                <div className="d-flex justify-content-between align-items-start">
                  <span className={`small ${cell.inMonth ? 'fw-semibold' : 'text-muted'}`}>
                    {cell.dateObj.getDate()}
                  </span>
                  {isToday && <Badge bg="primary">Hoy</Badge>}
                </div>

                <div className="mt-1 d-flex flex-column gap-1">
                  {dayEvents.slice(0, 2).map(ev => (
                    <Badge
                      key={ev.id}
                      bg="danger"
                      className="text-truncate"
                      title={ev.title}
                      style={{ maxWidth: '100%' }}
                    >
                      {ev.title}
                    </Badge>
                  ))}
                  {dayEvents.length > 2 && (
                    <Badge bg="secondary">+{dayEvents.length - 2} más</Badge>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Lista del mes */}
        <Card className="mt-3">
          <Card.Header className="fw-semibold">Pruebas del mes</Card.Header>
          <ListGroup variant="flush">
            {monthEvents.length === 0 && (
              <ListGroup.Item className="text-muted">Sin pruebas registradas.</ListGroup.Item>
            )}
            {monthEvents.map(ev => (
              <ListGroup.Item key={ev.id} className="d-flex justify-content-between align-items-center">
                <div>
                  <div className="fw-semibold">{ev.title}</div>
                  <div className="small text-muted">Curso: {ev.course || '—'}</div>
                </div>
                <Badge bg="dark">{ev.date}</Badge>
              </ListGroup.Item>
            ))}
          </ListGroup>
        </Card>
      </Card.Body>
    </Card>
  );
}
