import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";

const baseFont =
  "'Poppins', system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif";

export default function NavBar() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();

  // Cierra el menú al cambiar de ruta
  useEffect(() => setOpen(false), [pathname]);

  // Cierra el menú si ensanchas la ventana (pasas a desktop)
  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth > 768 && open) setOpen(false);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [open]);

  return (
    <header style={{ fontFamily: baseFont }}>
      {/* estilos embebidos para soportar media queries */}
      <style>{`
        .ap-nav { position: sticky; top: 0; z-index: 1030; background: #004aad; color: #fff; }
        .ap-nav__bar { display: flex; align-items: center; justify-content: space-between; padding: 10px 14px; max-width: 1200px; margin: 0 auto; }
        .ap-nav__logo { margin: 0; font-weight: 800; letter-spacing: .5px; font-size: 20px; color: #fff; text-decoration: none; }
        .ap-nav__toggle { appearance: none; background: transparent; border: 0; color: #fff; width: 44px; height: 44px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; }
        .ap-nav__toggle:active { background: rgba(255,255,255,.12); }
        .ap-nav__icon, .ap-nav__icon::before, .ap-nav__icon::after {
          content: ""; display: block; width: 22px; height: 2px; background: currentColor; border-radius: 2px; transition: transform .2s ease, opacity .2s ease;
        }
        .ap-nav__icon::before { transform: translateY(-6px); }
        .ap-nav__icon::after { transform: translateY(6px); }
        .ap-nav__toggle[aria-expanded="true"] .ap-nav__icon { opacity: 0; }
        .ap-nav__toggle[aria-expanded="true"] .ap-nav__icon::before { transform: translateY(0) rotate(45deg); opacity: 1; }
        .ap-nav__toggle[aria-expanded="true"] .ap-nav__icon::after { transform: translateY(0) rotate(-45deg); opacity: 1; }

        /* Menú */
        .ap-nav__menu { list-style: none; margin: 0; padding: 0; display: flex; gap: 20px; }
        .ap-nav__link { color: #fff; text-decoration: none; font-weight: 600; display: inline-block; padding: 8px 6px; border-radius: 6px; }
        .ap-nav__link:hover { background: rgba(255,255,255,.12); }
        .ap-nav__link--active { background: rgba(255,255,255,.18); }

        /* Mobile */
        @media (max-width: 768px) {
          .ap-nav__menu {
            position: fixed; left: 0; right: 0; top: 56px; /* altura de la barra */
            background: #004aad; border-top: 1px solid rgba(255,255,255,.2);
            flex-direction: column; gap: 0; padding: 8px 12px 12px;
            display: none;
          }
          .ap-nav__menu.is-open { display: flex; }
          .ap-nav__link { padding: 12px; }
          .ap-nav__backdrop {
            position: fixed; inset: 56px 0 0 0; background: rgba(0,0,0,.25); display: none;
          }
          .ap-nav__backdrop.is-open { display: block; }
        }
      `}</style>

      <nav className="ap-nav">
        <div className="ap-nav__bar">
          <Link to="/" className="ap-nav__logo">AulaPlus</Link>

          {/* Desktop menu */}
          <ul className="ap-nav__menu d-none d-md-flex">
            <li><Link to="/" className={`ap-nav__link ${pathname === "/" ? "ap-nav__link--active" : ""}`}>Inicio</Link></li>
            <li><Link to="/contact" className={`ap-nav__link ${pathname === "/contact" ? "ap-nav__link--active" : ""}`}>Contacto</Link></li>
            <li><Link to="/contact" className={`ap-nav__link ${pathname === "/contact" ? "ap-nav__link--active" : ""}`}>Direccion</Link></li>
            <li><Link to="/contact" className={`ap-nav__link ${pathname === "/contact" ? "ap-nav__link--active" : ""}`}>Aula Virtual</Link></li>
          </ul>

          {/* Toggle (siempre visible, útil en xs/sm) */}
          <button
            className="ap-nav__toggle d-md-none"
            aria-expanded={open ? "true" : "false"}
            aria-controls="menu-movil"
            onClick={() => setOpen(v => !v)}
          >
            <span className="ap-nav__icon" />
          </button>
        </div>

        {/* Mobile menu */}
        <ul id="menu-movil" className={`ap-nav__menu ${open ? "is-open" : ""} d-md-none`}>
          <li><Link to="/" className="ap-nav__link">Inicio</Link></li>
          <li><Link to="/contact" className="ap-nav__link">Contacto</Link></li>
          <li><Link to="/contact" className="ap-nav__link">Direccion</Link></li>
          <li><Link to="/contact" className="ap-nav__link">Aula Virtual</Link></li>
        </ul>
        {/* Backdrop para cerrar tocando fuera */}
        <div
          className={`ap-nav__backdrop ${open ? "is-open" : ""} d-md-none`}
          onClick={() => setOpen(false)}
        />
      </nav>
    </header>
  );
}
