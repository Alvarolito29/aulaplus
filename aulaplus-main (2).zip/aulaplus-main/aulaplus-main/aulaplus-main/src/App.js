// src/app/App.jsx
import { Suspense, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { Container, Spinner } from "react-bootstrap";
import NavBar from "./components/NavBar";              // ✅ ruta exacta
import routes from "./app/routes";                     // ✅ tu arreglo de rutas

// Sube la página al tope en cada navegación
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
  }, [pathname]);
  return null;
}

function AppRoutes() {
  return (
    <Routes>
      {routes.map((r, i) => (
        <Route key={i} path={r.path} element={r.element} />
      ))}
      {/* Si NO tienes un catch-all en routes, puedes habilitar esto:
      <Route path="*" element={<div style={{ padding: 24 }}>Página no encontrada</div>} />
      */}
    </Routes>
  );
}

export default function App() {
  return (
    <Router>
      <ScrollToTop />
      <NavBar />
      <Suspense
        fallback={
          <Container className="py-5 text-center">
            <Spinner animation="border" role="status" />
            <div className="mt-2">Cargando…</div>
          </Container>
        }
      >
        <AppRoutes />
      </Suspense>
    </Router>
  );
}
