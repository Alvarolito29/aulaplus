// src/pages/Profesores.jsx
import { useState, Fragment } from "react";
import {
  Container,
  Row,
  Col,
  Card,
  Button,
  Form,
  ListGroup,
  Table,
  Badge,
  Alert,
  InputGroup,
} from "react-bootstrap";

/* ================== MOCK DB (reemplaza con tu API) ================== */
// Claves normalizadas: RUT sin puntos ni guión, DV en mayúscula (ver normalizeRut)
const FAKE_DB_PROFES = {
  "123456785": {
    nombre: "Carolina Rivas",
    password: "1234",
    cursos: [
      {
        id: "mat-1A",
        nombre: "Matemáticas 1° Medio A",
        asignatura: "Matemáticas",
        nivel: "1° Medio",
        seccion: "A",
        alumnos: [
          { id: "a1", nombre: "Ana Torres", rut: "12.345.222-8", notas: [6.5, 5.8, 6.0] },
          { id: "a2", nombre: "Luis Díaz", rut: "13.456.333-7", notas: [5.2, 5.0, 5.6] },
          { id: "a3", nombre: "María Soto", rut: "14.567.444-6", notas: [6.2, 6.4, 6.1] },
        ],
      },
      {
        id: "mat-1B",
        nombre: "Matemáticas 1° Medio B",
        asignatura: "Matemáticas",
        nivel: "1° Medio",
        seccion: "B",
        alumnos: [
          { id: "b1", nombre: "Javier Peña", rut: "15.678.555-5", notas: [4.9, 5.1, 5.0] },
          { id: "b2", nombre: "Camila Ruiz", rut: "16.789.666-4", notas: [6.0, 6.1, 6.3] },
        ],
      },
    ],
  },
  "98765432K": {
    nombre: "Juan Castillo",
    password: "abcd",
    cursos: [
      {
        id: "len-2A",
        nombre: "Lenguaje 2° Medio A",
        asignatura: "Lenguaje",
        nivel: "2° Medio",
        seccion: "A",
        alumnos: [
          { id: "c1", nombre: "Benjamín Castro", rut: "11.222.333-4", notas: [5.8, 5.9, 6.1] },
          { id: "c2", nombre: "Sofía Muñoz", rut: "12.333.444-5", notas: [6.3, 6.0, 6.4] },
        ],
      },
    ],
  },
};

/* ================== Helpers ================== */
function normalizeRut(str) {
  return (str || "").replace(/\./g, "").replace(/-/g, "").toUpperCase();
}
function promedio(arr) {
  if (!arr?.length) return 0;
  const n = arr.reduce((a, b) => a + b, 0) / arr.length;
  return Math.round(n * 10) / 10; // 1 decimal
}

/* ================== Página ================== */
export default function Profesores() {
  // Auth
  const [rut, setRut] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [sesion, setSesion] = useState(null); // { rut, nombre, cursos }
  // UI
  const [cursoAbierto, setCursoAbierto] = useState(null); // id curso abierto
  const [alumnoFiltro, setAlumnoFiltro] = useState("");
  const [expandidos, setExpandidos] = useState(() => new Set()); // `${cursoId}:${alumnoId}`

  const handleLogin = (e) => {
    e.preventDefault();
    setError("");
    const key = normalizeRut(rut);
    const user = FAKE_DB_PROFES[key];
    if (!user || user.password !== password) {
      setError("Credenciales inválidas. Verifica RUT y contraseña.");
      return;
    }
    setSesion({ rut: key, nombre: user.nombre, cursos: user.cursos });
    setPassword("");
    setCursoAbierto(null);
    setAlumnoFiltro("");
    setExpandidos(new Set());
  };

  const handleLogout = () => {
    setSesion(null);
    setRut("");
    setPassword("");
    setError("");
    setCursoAbierto(null);
    setAlumnoFiltro("");
    setExpandidos(new Set());
  };

  const toggleCurso = (id) => {
    setCursoAbierto((prev) => (prev === id ? null : id));
    setAlumnoFiltro(""); // limpia filtro al cambiar de curso
    setExpandidos(new Set());
  };

  const toggleExpandAlumno = (cursoId, alumnoId) => {
    const key = `${cursoId}:${alumnoId}`;
    setExpandidos((prev) => {
      const n = new Set(prev);
      if (n.has(key)) n.delete(key);
      else n.add(key);
      return n;
    });
  };

  const cursos = sesion?.cursos ?? [];

  return (
    <main style={{ background: "#f6f7fb", minHeight: "100vh", padding: "24px 0" }}>
      <Container fluid="xl">
        <Row className="justify-content-center">
          <Col lg={10} xl={9}>
            <Card className="shadow-sm rounded-3">
              <Card.Header as="h5" className="fw-bold">Portal de Profesores</Card.Header>
              <Card.Body>
                {!sesion ? (
                  <>
                    {error && <Alert variant="danger" className="mb-3">{error}</Alert>}
                    <Form onSubmit={handleLogin}>
                      <Row className="g-3">
                        <Col md={6}>
                          <Form.Group controlId="rut">
                            <Form.Label>RUT</Form.Label>
                            <Form.Control
                              type="text"
                              placeholder="12.345.678-5"
                              value={rut}
                              onChange={(e) => setRut(e.target.value)}
                              autoComplete="username"
                              required
                            />
                            <Form.Text className="text-muted">Formato: 12.345.678-5</Form.Text>
                          </Form.Group>
                        </Col>
                        <Col md={6}>
                          <Form.Group controlId="password">
                            <Form.Label>Contraseña</Form.Label>
                            <Form.Control
                              type="password"
                              placeholder="********"
                              value={password}
                              onChange={(e) => setPassword(e.target.value)}
                              autoComplete="current-password"
                              required
                            />
                          </Form.Group>
                        </Col>
                      </Row>
                      <div className="d-flex gap-2 mt-3">
                        <Button type="submit" variant="primary" className="fw-semibold">Ingresar</Button>
                        <Button
                          type="button"
                          variant="outline-secondary"
                          onClick={() => {
                            setRut("");
                            setPassword("");
                            setError("");
                          }}
                        >
                          Limpiar
                        </Button>
                      </div>

                      {/* Credenciales demo */}
                      <Alert variant="light" className="mt-3 mb-0">
                        <div className="small mb-1 fw-semibold">Demo</div>
                        <div className="small">RUT: 12.345.678-5 — Clave: 1234</div>
                        <div className="small">RUT: 9.876.543-2 — DV K — Clave: abcd</div>
                      </Alert>
                    </Form>
                  </>
                ) : (
                  <>
                    {/* Header sesión */}
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <div>
                        <div className="fw-bold">Hola, {sesion.nombre}</div>
                        <div className="text-muted small">RUT: {rut || sesion.rut}</div>
                      </div>
                      <Button variant="outline-danger" size="sm" onClick={handleLogout}>
                        Cerrar sesión
                      </Button>
                    </div>

                    {/* Lista de cursos */}
                    <Card className="border-0">
                      <Card.Title className="h6">Mis cursos</Card.Title>

                      {!cursos.length && (
                        <Alert variant="warning" className="mb-0">No tienes cursos asignados.</Alert>
                      )}

                      <ListGroup variant="flush" className="mt-2">
                        {cursos.map((c) => {
                          const abierto = cursoAbierto === c.id;

                          // 🔧 Importante: NADA de hooks acá.
                          const alumnosFiltrados = (() => {
                            const t = alumnoFiltro.trim().toLowerCase();
                            if (!t) return c.alumnos;
                            return c.alumnos.filter(
                              (a) =>
                                a.nombre.toLowerCase().includes(t) ||
                                a.rut.toLowerCase().includes(t)
                            );
                          })();

                          const cursoPromedio =
                            promedio(
                              c.alumnos.flatMap((a) =>
                                a.notas?.length ? [promedio(a.notas)] : []
                              )
                            ) || 0;

                          return (
                            <ListGroup.Item key={c.id} className="py-3">
                              <div className="d-flex justify-content-between align-items-center">
                                <div>
                                  <div className="fw-semibold">{c.nombre}</div>
                                  <div className="text-muted small">
                                    {c.asignatura} • {c.nivel} {c.seccion} • {c.alumnos.length} alumnos
                                  </div>
                                </div>
                                <div className="d-flex gap-2">
                                  <Badge bg="info" pill>Prom. curso: {cursoPromedio}</Badge>
                                  <Button
                                    variant={abierto ? "secondary" : "primary"}
                                    size="sm"
                                    onClick={() => toggleCurso(c.id)}
                                  >
                                    {abierto ? "Ocultar" : "Ver alumnos"}
                                  </Button>
                                </div>
                              </div>

                              {abierto && (
                                <div className="mt-3">
                                  {/* Filtro alumnos */}
                                  <InputGroup className="mb-2">
                                    <InputGroup.Text>Buscar</InputGroup.Text>
                                    <Form.Control
                                      placeholder="Nombre o RUT…"
                                      value={alumnoFiltro}
                                      onChange={(e) => setAlumnoFiltro(e.target.value)}
                                    />
                                  </InputGroup>

                                  {/* Tabla alumnos */}
                                  <div className="table-responsive">
                                    <Table bordered hover size="sm" className="align-middle">
                                      <thead>
                                        <tr>
                                          <th style={{ width: "36%" }}>Alumno</th>
                                          <th style={{ width: "24%" }}>RUT</th>
                                          <th style={{ width: "20%" }}>Promedio</th>
                                          <th style={{ width: "20%" }}>Acciones</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {alumnosFiltrados.map((a) => {
                                          const rowKey = `${c.id}:${a.id}`;
                                          const isOpen = expandidos.has(rowKey);
                                          return (
                                            <Fragment key={rowKey}>
                                              <tr>
                                                <td className="fw-semibold">{a.nombre}</td>
                                                <td className="text-muted">{a.rut}</td>
                                                <td>
                                                  <Badge bg={promedio(a.notas) >= 4 ? "success" : "danger"}>
                                                    {promedio(a.notas)}
                                                  </Badge>
                                                </td>
                                                <td>
                                                  <div className="d-flex gap-2">
                                                    <Button
                                                      size="sm"
                                                      variant={isOpen ? "secondary" : "outline-primary"}
                                                      onClick={() => toggleExpandAlumno(c.id, a.id)}
                                                    >
                                                      {isOpen ? "Ocultar notas" : "Ver notas"}
                                                    </Button>
                                                    <Button size="sm" variant="outline-secondary" disabled>
                                                      Editar
                                                    </Button>
                                                  </div>
                                                </td>
                                              </tr>
                                              {isOpen && (
                                                <tr>
                                                  <td colSpan={4}>
                                                    {a.notas?.length ? (
                                                      <div className="d-flex flex-wrap gap-2">
                                                        {a.notas.map((n, idx) => (
                                                          <Badge
                                                            key={idx}
                                                            bg={n >= 4 ? "success" : "danger"}
                                                            className="px-3 py-2"
                                                          >
                                                            {`Nota ${idx + 1}: ${n}`}
                                                          </Badge>
                                                        ))}
                                                      </div>
                                                    ) : (
                                                      <span className="text-muted">Sin notas registradas.</span>
                                                    )}
                                                  </td>
                                                </tr>
                                              )}
                                            </Fragment>
                                          );
                                        })}
                                        {!alumnosFiltrados.length && (
                                          <tr>
                                            <td colSpan={4} className="text-center text-muted">
                                              Sin resultados para “{alumnoFiltro}”.
                                            </td>
                                          </tr>
                                        )}
                                      </tbody>
                                    </Table>
                                  </div>
                                </div>
                              )}
                            </ListGroup.Item>
                          );
                        })}
                      </ListGroup>
                    </Card>
                  </>
                )}
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </main>
  );
}
