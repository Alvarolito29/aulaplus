import { useState, useMemo } from "react";
import {
  Container,
  Row,
  Col,
  Card,
  Button,
  Badge,
  ListGroup,
  Form,
  Modal,
  Alert,
} from "react-bootstrap";
import CalendarioPruebas from "../components/CalendarioPruebas";

// ===== Datos de ejemplo =====
const COURSES = [
  { id: "historia",    title: "Historia",            teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "lenguaje",    title: "Lenguaje",            teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "matematicas", title: "Matemáticas",         teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "ingles",      title: "Inglés",              teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "religion",    title: "Religión",            teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "fisica",      title: "Física",              teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "biologia",    title: "Biología",            teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "ed-fisica",   title: "Educación Física",    teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "futbol",      title: "Taller de Fútbol",    teacher: "Por asignar", category: "Taller",     color: "success"   },
];

const EXAM_EVENTS = [
  { id: 'e1', title: 'Prueba Unidad 2',      course: 'Matemáticas 1° Medio', date: '2025-11-05' },
  { id: 'e2', title: 'Lectura Comprensiva',  course: 'Lenguaje 2° Medio',    date: '2025-11-12' },
  { id: 'e3', title: 'Trabajo Integrador',   course: 'Matemáticas 1° Medio', date: '2025-11-20' },
];

// ===== Helpers =====
const isValidEmail = (v) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v || "").trim());

const buildMailto = ({ to, subject, body }) => {
  const params = new URLSearchParams();
  if (subject) params.set("subject", subject);
  if (body) params.set("body", body);
  return `mailto:${encodeURIComponent(to)}?${params.toString()}`;
};

// ===== Componente =====
export default function Estudiantes() {
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return COURSES;
    return COURSES.filter(c =>
      c.title.toLowerCase().includes(t) || c.category.toLowerCase().includes(t)
    );
  }, [q]);

  // Estado del modal de mensajes
  const [showMsg, setShowMsg] = useState(false);
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sent, setSent] = useState(false);

  const canSend = isValidEmail(to) && body.trim().length > 0;

  const openMsg = () => {
    setShowMsg(true);
    setSent(false);
  };
  const closeMsg = () => {
    setShowMsg(false);
    setTo("");
    setSubject("");
    setBody("");
    setSent(false);
  };

  const handleSend = () => {
    if (!canSend) return;
    // Sin backend: usa mailto (abre cliente de correo)
    const href = buildMailto({ to, subject, body });
    window.location.href = href;
    setSent(true);
    // Si quieres cerrar al instante, descomenta:
    // closeMsg();
  };

  return (
    <main style={{ background: "#f6f7fb", minHeight: "100vh", padding: "24px 0" }}>
      <Container fluid="xl">
        <Row className="mb-3">
          <Col md={8}>
            <h1 style={{ fontWeight: 800, letterSpacing: ".2px", marginBottom: 4 }}>Actividad</h1>
            <p style={{ margin: 0, opacity: 0.8 }}>
              Tu resumen al día: anuncios, tareas y próximos eventos.
            </p>
          </Col>
          <Col md={4}>
            <Form className="d-flex" onSubmit={(e)=>e.preventDefault()}>
              <Form.Control
                placeholder="Buscar en tus cursos…"
                value={q}
                onChange={(e)=>setQ(e.target.value)}
              />
            </Form>
          </Col>
        </Row>

        <Row className="g-4">
          <Col lg={2}>
            <nav style={{ position:"sticky", top:16, borderRadius:8, overflow:"hidden", background:"#fff" }}>
              <ListGroup variant="flush">
                <ListGroup.Item
                  action
                  style={{ fontWeight:700, color:"#fff", background:"#004aad" }}
                >
                  📰 Actividad
                </ListGroup.Item>

                <ListGroup.Item
                  action
                  onClick={()=>document.getElementById("mis-cursos")?.scrollIntoView({behavior:"smooth"})}
                >
                  📚 Mis cursos
                </ListGroup.Item>

                <ListGroup.Item
                  action
                  onClick={()=>document.getElementById("calendario")?.scrollIntoView({behavior:"smooth"})}
                >
                  🗓️ Calendario
                </ListGroup.Item>

                {/* 👉 Abre el modal de mensajes */}
                <ListGroup.Item action onClick={openMsg}>
                  📬 Mensajes
                </ListGroup.Item>
              </ListGroup>
            </nav>
          </Col>

          <Col lg={7}>
            {/* Importante */}
            <section>
              <h5 style={{ fontWeight:800, marginBottom:12 }}>Importante</h5>

              <Card className="mb-2">
                <Card.Body>
                  <Badge bg="danger" className="mb-2">Anuncio</Badge>
                  <Card.Title>Mantenimiento del Campus</Card.Title>
                  <Card.Text>Domingo 02:00–04:00. Acceso intermitente.</Card.Text>
                  <div className="d-flex gap-2">
                    <Button as="a" href="#mis-cursos" size="sm">Ir a mis cursos</Button>
                    <Button as="a" href="/products" size="sm" variant="outline-secondary">Ver catálogo</Button>
                  </div>
                </Card.Body>
              </Card>

              <Card>
                <Card.Body>
                  <Badge bg="warning" text="dark" className="mb-2">Entrega</Badge>
                  <Card.Title>Proyecto: App React (INF-221)</Card.Title>
                  <Card.Text>Fecha límite: <strong>Vie 31 • 23:59</strong></Card.Text>
                  <div className="d-flex gap-2">
                    <Button as="a" href="#mis-cursos" size="sm">Abrir curso</Button>
                    <Button as="a" href="/products" size="sm" variant="outline-secondary">Rúbrica</Button>
                  </div>
                </Card.Body>
              </Card>
            </section>

            {/* Mis cursos */}
            <section id="mis-cursos" style={{ marginTop:24 }}>
              <h5 style={{ fontWeight:800, marginBottom:12 }}>Mis cursos</h5>
              <Row className="g-3">
                {list.map(c => (
                  <Col key={c.id} xs={12} md={6} lg={4}>
                    <Card style={{ borderRadius:12 }}>
                      <Card.Body>
                        <Badge bg={c.color} className="mb-2">{c.category}</Badge>
                        <Card.Title style={{ fontWeight:700 }}>{c.title}</Card.Title>
                        <Card.Text style={{ opacity:.8 }}>Docente: {c.teacher}</Card.Text>
                        <div className="d-flex gap-2">
                          <Button as="a" href={`/curso/${c.id}`} size="sm">Entrar</Button>
                          <Button as="a" href={`/curso/${c.id}`} size="sm" variant="outline-secondary">Contenido</Button>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                ))}
              </Row>
            </section>
          </Col>

          <Col lg={3}>
            <div id="calendario">
              <CalendarioPruebas events={EXAM_EVENTS} />
            </div>
          </Col>
        </Row>
      </Container>

      {/* ===== Modal de Mensajes ===== */}
      <Modal show={showMsg} onHide={closeMsg} centered>
        <Modal.Header closeButton>
          <Modal.Title>Enviar mensaje</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {sent && (
            <Alert variant="success">
              Abriendo tu cliente de correo… Si no se abre, revisa el bloqueador de ventanas emergentes.
            </Alert>
          )}

          <Form onSubmit={(e) => { e.preventDefault(); handleSend(); }}>
            <Form.Group className="mb-3" controlId="msg-to">
              <Form.Label>Para (correo)</Form.Label>
              <Form.Control
                type="email"
                placeholder="destinatario@colegio.cl"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                isInvalid={to !== "" && !isValidEmail(to)}
                required
                autoFocus
              />
              <Form.Control.Feedback type="invalid">
                Ingresa un correo válido.
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group className="mb-3" controlId="msg-subject">
              <Form.Label>Asunto</Form.Label>
              <Form.Control
                type="text"
                placeholder="Consulta / Aviso / Coordinación…"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-2" controlId="msg-body">
              <Form.Label>Mensaje</Form.Label>
              <Form.Control
                as="textarea"
                rows={6}
                placeholder="Escribe tu mensaje…"
                value={body}
                onChange={(e) => setBody(e.target.value)}
                required
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer className="d-flex justify-content-between">
          <Button variant="outline-secondary" onClick={closeMsg}>
            Cancelar
          </Button>
          <Button variant="primary" onClick={handleSend} disabled={!canSend}>
            Enviar
          </Button>
        </Modal.Footer>
      </Modal>
    </main>
  );
}
