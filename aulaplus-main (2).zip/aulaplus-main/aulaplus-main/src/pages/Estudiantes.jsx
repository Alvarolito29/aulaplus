import { useState, useMemo } from "react";
import { Container, Row, Col, Card, Button, Badge, ListGroup, Form } from "react-bootstrap";

// Lista interna (blindado)
const COURSES = [
  { id: "historia",    title: "Historia",            teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "lenguaje",    title: "Lenguaje",            teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "matematicas", title: "Matemáticas",         teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "ingles",      title: "Inglés",              teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "religion",    title: "Religión",            teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "fisica",      title: "Física",              teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "biologia",    title: "Biología",            teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "ed-fisica",   title: "Educación Física",    teacher: "Por asignar", category: "Asignatura", color: "secondary" },
  { id: "futbol",      title: "Taller de Fútbol",    teacher: "Por asignar", category: "Taller",     color: "success"   },
];

export default function Estudiantes() {
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return COURSES;
    return COURSES.filter(c =>
      c.title.toLowerCase().includes(t) || c.category.toLowerCase().includes(t)
    );
  }, [q]);

  return (
    <main style={{ background: "#f6f7fb", minHeight: "100vh", padding: "24px 0" }}>
      <Container fluid="xl">
        <Row className="mb-3">
          <Col md={8}>
            <h1 style={{ fontWeight: 800, letterSpacing: ".2px", marginBottom: 4 }}>Actividad</h1>
            <p style={{ margin: 0, opacity: 0.8 }}>Tu resumen al día: anuncios, tareas y próximos eventos.</p>
          </Col>
          <Col md={4}>
            <Form className="d-flex" onSubmit={(e)=>e.preventDefault()}>
              <Form.Control
                placeholder="Buscar en tus cursos…"
                value={q}
                onChange={(e)=>setQ(e.target.value)}
              />
            </Form>
          </Col>
        </Row>

        <Row className="g-4">
          <Col lg={2}>
            <nav style={{ position:"sticky", top:16, borderRadius:8, overflow:"hidden", background:"#fff" }}>
              <ListGroup variant="flush">
                <ListGroup.Item action style={{ fontWeight:700, color:"#fff", background:"#004aad" }}>📰 Actividad</ListGroup.Item>
                <ListGroup.Item action onClick={()=>document.getElementById("mis-cursos")?.scrollIntoView({behavior:"smooth"})}>📚 Mis cursos</ListGroup.Item>
                <ListGroup.Item action>🗓️ Calendario</ListGroup.Item>
                <ListGroup.Item action>📬 Mensajes</ListGroup.Item>
              </ListGroup>
            </nav>
          </Col>

          <Col lg={7}>
            {/* Importante */}
            <section>
              <h5 style={{ fontWeight:800, marginBottom:12 }}>Importante</h5>
              <Card className="mb-2">
                <Card.Body>
                  <Badge bg="danger" className="mb-2">Anuncio</Badge>
                  <Card.Title>Mantenimiento del Campus</Card.Title>
                  <Card.Text>Domingo 02:00–04:00. Acceso intermitente.</Card.Text>
                  <div className="d-flex gap-2">
                    <Button as="a" href="#mis-cursos" size="sm">Ir a mis cursos</Button>
                    <Button as="a" href="/products" size="sm" variant="outline-secondary">Ver catálogo</Button>
                  </div>
                </Card.Body>
              </Card>

              <Card>
                <Card.Body>
                  <Badge bg="warning" text="dark" className="mb-2">Entrega</Badge>
                  <Card.Title>Proyecto: App React (INF-221)</Card.Title>
                  <Card.Text>Fecha límite: <strong>Vie 31 • 23:59</strong></Card.Text>
                  <div className="d-flex gap-2">
                    <Button as="a" href="#mis-cursos" size="sm">Abrir curso</Button>
                    <Button as="a" href="/products" size="sm" variant="outline-secondary">Rúbrica</Button>
                  </div>
                </Card.Body>
              </Card>
            </section>

            {/* Mis cursos */}
            <section id="mis-cursos" style={{ marginTop:24 }}>
              <h5 style={{ fontWeight:800, marginBottom:12 }}>Mis cursos</h5>
              <Row className="g-3">
                {list.map(c => (
                  <Col key={c.id} xs={12} md={6} lg={4}>
                    <Card style={{ borderRadius:12 }}>
                      <Card.Body>
                        <Badge bg={c.color} className="mb-2">{c.category}</Badge>
                        <Card.Title style={{ fontWeight:700 }}>{c.title}</Card.Title>
                        <Card.Text style={{ opacity:.8 }}>Docente: {c.teacher}</Card.Text>
                        <div className="d-flex gap-2">
                          <Button as="a" href={`/curso/${c.id}`} size="sm">Entrar</Button>
                          <Button as="a" href={`/curso/${c.id}`} size="sm" variant="outline-secondary">Contenido</Button>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                ))}
              </Row>
            </section>
          </Col>

          <Col lg={3}>
            <Card>
              <Card.Body>
                <Card.Title>Calendario</Card.Title>
                <ListGroup variant="flush">
                  <ListGroup.Item className="d-flex justify-content-between">Control BD Aplicadas <Badge bg="warning" text="dark">Lun</Badge></ListGroup.Item>
                  <ListGroup.Item className="d-flex justify-content-between">Entrega Proyecto React <Badge bg="danger">Vie</Badge></ListGroup.Item>
                </ListGroup>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </main>
  );
}

