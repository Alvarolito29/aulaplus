export default function Admision() {
  return (
    <main style={{ minHeight: '60vh', background: '#fff' }}>
      <div style={{ padding: 24 }}>
        <h1>Admisión</h1>
        <p>Pantalla en blanco lista para contenido.</p>
      </div>
    </main>
  );
}
