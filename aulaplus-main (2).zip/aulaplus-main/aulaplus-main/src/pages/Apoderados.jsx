export default function Apoderados() {
  return (
    <main style={{ minHeight: '60vh', background: '#fff' }}>
      <div style={{ padding: 24 }}>
        <h1>Apoderados</h1>
        <p>Pantalla en blanco lista para contenido.</p>
      </div>
    </main>
  );
}

